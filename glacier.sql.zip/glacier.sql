-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mar. 08 août 2023 à 16:19
-- Version du serveur : 10.6.12-MariaDB-0ubuntu0.22.04.1
-- Version de PHP : 8.2.8

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `glacier`
--

-- --------------------------------------------------------

--
-- Structure de la table `congélateurs`
--

CREATE TABLE IF NOT EXISTS `congélateurs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(190) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `congélateurs`
--

INSERT INTO `congélateurs` (`id`, `nom`, `description`) VALUES
(1, 'zone 1', 'congélateur 1'),
(2, 'zone 2', 'congélateur 2'),
(3, 'zone 3', 'congélateur 3'),
(4, 'zone 4', 'congélateur 4'),
(5, 'zone 5', 'congélateur 5'),
(6, 'zone 6', 'congélateur 6'),
(7, 'zone 7', 'congélateur 7'),
(8, 'zone 8', 'congélateur 8'),
(9, 'zone 9', 'congélateur 9'),
(10, 'zone 10', 'congélateur 10');

-- --------------------------------------------------------

--
-- Structure de la table `congélateur_glace`
--

CREATE TABLE IF NOT EXISTS `congélateur_glace` (
  `congélateur_id` bigint(20) UNSIGNED NOT NULL,
  `glace_id` bigint(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`congélateur_id`,`glace_id`) USING BTREE,
  KEY `congélateur_id` (`congélateur_id`),
  KEY `glace_id` (`glace_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `congélateur_utilisateur`
--

CREATE TABLE IF NOT EXISTS `congélateur_utilisateur` (
  `congélateur_id` bigint(10) UNSIGNED NOT NULL,
  `utilisateur_id` bigint(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`congélateur_id`,`utilisateur_id`),
  KEY `congélateur_id` (`congélateur_id`),
  KEY `utilisateur_id` (`utilisateur_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `glaces`
--

CREATE TABLE IF NOT EXISTS `glaces` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `volume` int(11) NOT NULL,
  `date_production` date NOT NULL,
  `date_sortie` date NOT NULL,
  `parfum_id` bigint(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_glaces_parfum_id` (`parfum_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `glaces`
--

INSERT INTO `glaces` (`id`, `volume`, `date_production`, `date_sortie`, `parfum_id`) VALUES
(1, 10, '2023-08-01', '2023-09-01', 1),
(2, 14, '2023-09-12', '2023-10-21', 10),
(3, 18, '2023-09-30', '2023-11-06', 6),
(4, 11, '2023-07-19', '2023-09-13', 5),
(5, 16, '2023-09-15', '2023-09-23', 3),
(6, 18, '2023-07-28', '2023-10-07', 2),
(7, 10, '2023-06-24', '2023-10-26', 7),
(8, 16, '2023-07-16', '2023-09-22', 4),
(9, 15, '2023-08-05', '2023-10-14', 8),
(10, 13, '2023-08-27', '2023-10-09', 9);

-- --------------------------------------------------------

--
-- Structure de la table `parfums`
--

CREATE TABLE IF NOT EXISTS `parfums` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(190) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `parfums`
--

INSERT INTO `parfums` (`id`, `nom`, `description`) VALUES
(1, 'vanille', 'vanille de madagascar'),
(2, 'chocolat', 'chocolat au lait'),
(3, 'fraise', 'fraise favette'),
(4, 'pistache', 'pistache de bront'),
(5, 'stracciatella', 'lait entier, crème fraîche et pépites de chocolat'),
(6, 'caramel', 'caramel d\'enfance'),
(7, 'citron', 'sorbet citron'),
(8, 'framboise', 'sorbet framboise'),
(9, 'menthe', 'menthe et pépite de chocolat'),
(10, 'café', 'café et pépites de chocolat');

-- --------------------------------------------------------

--
-- Structure de la table `rôles`
--

CREATE TABLE IF NOT EXISTS `rôles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(190) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `rôles`
--

INSERT INTO `rôles` (`id`, `nom`) VALUES
(1, 'serveur'),
(2, 'responsable'),
(3, 'gérant');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(190) NOT NULL,
  `password` varchar(190) NOT NULL,
  `rôle_id` bigint(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_utilisateurs_rôle_id` (`rôle_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `email`, `password`, `rôle_id`) VALUES
(1, 'foo@example.com', 'motdepasse', 1),
(2, 'lpont1@uiuc.edu', '123', 2),
(3, 'mmarchelli2@globo.com', '123', 1),
(4, 'kgrabiec3@dagondesign.com', '123', 3),
(5, 'fkennett4@freewebs.com', '123', 1),
(6, 'ecutbush5@reverbnation.com', '123', 1),
(7, 'mgarner6@disqus.com', '123', 1),
(8, 'blevermore7@psu.edu', '123', 1),
(9, 'fshilstone8@nationalgeographic.com', '123', 2),
(10, 'scarrell9@craigslist.org', '123', 1);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `congélateur_glace`
--
ALTER TABLE `congélateur_glace`
  ADD CONSTRAINT `fk_congélateur_glace_congélateur_id` FOREIGN KEY (`congélateur_id`) REFERENCES `congélateurs` (`id`),
  ADD CONSTRAINT `fk_congélateur_glace_glace_id` FOREIGN KEY (`glace_id`) REFERENCES `glaces` (`id`);

--
-- Contraintes pour la table `congélateur_utilisateur`
--
ALTER TABLE `congélateur_utilisateur`
  ADD CONSTRAINT `fk_congélateur_utilisateur_utlisateur_id` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`),
  ADD CONSTRAINT `fk_congélateur_utlisateur_congélateur_id` FOREIGN KEY (`congélateur_id`) REFERENCES `congélateurs` (`id`);

--
-- Contraintes pour la table `glaces`
--
ALTER TABLE `glaces`
  ADD CONSTRAINT `fk_glaces_parfum_id` FOREIGN KEY (`parfum_id`) REFERENCES `parfums` (`id`);

--
-- Contraintes pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD CONSTRAINT `fk_utilisateurs_rôle_id` FOREIGN KEY (`rôle_id`) REFERENCES `rôles` (`id`);
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
